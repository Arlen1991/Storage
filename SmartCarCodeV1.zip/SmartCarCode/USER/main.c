#include "stm32f10x.h"
#include "delay.h"
#include "usart.h"
#include "motor.h"
#include "move.h"
#include "timer.h"
#include "led.h"
#include "servor.h"
#include "oled.h"
#include "show.h"
#include "beep.h"


u8 delay_50,delay_flag;
 int main(void)
 {	
    SysTick_Init();	
    Servor_GPIO_Config();
    Uart_Init(2); 
    Timer_Init();
    Timer_ON();			//������ʱ��	
    GPIO_LEDInint();
    delay_init();
     GPIO_LEDInint();
     Beep_Init();
     OLED_Init(); 
    Motor_Gpio_init();     
    PWM2_Init(1000,5);  // ��ʼ���������Ƶ�� 72/(5+1)  12KHZ 
      
    GraySensorIOInint(); 
       LED_Flash();
     Beep_Test();
     while(1)
     {
         oled_show();          //===��ʾ����
          delay_flag=1;	
		 delay_50=0;
        // CarGoStringht();
         CarSeachLine();
        while(delay_flag);
     }


 }
