#ifndef _LED_H
#define _LED_H
#include "sys.h"
#define ON  0
#define OFF 1


#define LED PBout(5)// PB5


void GPIO_LEDInint(void);
void LED_Flash(void);                             
#endif
