#ifndef __SERVOR_H
#define	__SERVOR_H

#include "stm32f10x.h"

void Servo1(void);
void Servor_GPIO_Config(void);	


#endif /* __GPIO_H */
