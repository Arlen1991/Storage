#include "stdio.h"
#include "stm32f10x.h"
#include "lcd.h"
#include "usart.h"	
#include "delay.h"
#include "wifi.h"


 int main(void)
 {	

    PCuart_init(115200);
    Wifiuart_init(9600);
    delay_init();
    LCD_Init();
    ESP8266_init();
    PC_Usart("Initation ok\r\n");
     delay_ms(1000);
     ConnectToServer();
  while(1)
  {
      ESP8266_Usart("wifi send ok \r\n");
    delay_ms(1000);
  }
 }
