#include "wifi.h"
#include "delay.h"
struct  STRUCT_USARTx_Fram strEsp8266_Fram_Record = { 0 };
void ESP8266_init( void )
{
    ESP8266_Net_Mode_Choose ( STA );
  	ESP8266_Cmd ( "AT+CIPMUX=0", "OK", 0, 500 );            //������ 

}


void ConnectToServer()
{
    bool state;
    
    /////���ӷ�����
    if(ESP8266_Cmd ( "AT", "OK", NULL, 1500 ))
    {
        PC_Usart("ESP8266 online");
        do
        {
            strEsp8266_Fram_Record .InfBit .FramLength = 0;               //���¿�ʼ�����µ����ݰ�
            memset(strEsp8266_Fram_Record .Data_RX_BUF,'\0',RX_BUF_MAX_LEN);	
            state=ESP8266_Cmd ( "AT+CIPSTART=\"TCP\",\"192.168.0.116\",85", "OK", "ALREADY", 2500 );
            PC_Usart(state);
        }
        while(state==false);
    }
    else 
    {
     PC_Usart("ESP8266 disable!");
    }
    
    PC_Usart("Already Connected!\r\n");
    ////����͸��ģʽ//0,��͸����1��͸��
    
     ESP8266_Cmd ( "AT+CIPMODE=1", "OK", 0, 800 );
  
     ESP8266_Cmd ( "AT+CIPSEND", "\r\n", ">", 500 );   

 
}

bool ESP8266_Net_Mode_Choose ( ENUM_Net_ModeTypeDef enumMode )
{
	switch ( enumMode )
	{
		case STA:
			return ESP8266_Cmd ( "AT+CWMODE=1", "OK", "no change", 2500 ); 
		
	  case AP:
		  return ESP8266_Cmd ( "AT+CWMODE=2", "OK", "no change", 2500 ); 
		
		case STA_AP:
		  return ESP8266_Cmd ( "AT+CWMODE=3", "OK", "no change", 2500 ); 
		
	  default:
		  return false;
  }
	
}

bool ESP8266_Cmd ( char * cmd, char * reply1, char * reply2, u32 waittime )
{    
	strEsp8266_Fram_Record .InfBit .FramLength = 0;               //���¿�ʼ�����µ����ݰ�

	ESP8266_Usart ( "%s\r\n", cmd );

	if ( ( reply1 == 0 ) && ( reply2 == 0 ) )                      //����Ҫ��������
		return true;
    
	do{
        if(waittime>1000)
        {
            delay_ms (1000);        
            waittime-=1000;
        }else
        {
            delay_ms (waittime);
            break;
        }
        
    }while(1);
	
	strEsp8266_Fram_Record .Data_RX_BUF [ strEsp8266_Fram_Record .InfBit .FramLength ]  = '\0';

    //����1���ack����
//	PC_Usart ( "%s", strEsp8266_Fram_Record .Data_RX_BUF );
  
	if ( ( reply1 != 0 ) && ( reply2 != 0 ) )
		return ( ( bool ) strstr ( strEsp8266_Fram_Record .Data_RX_BUF, reply1 ) || 
						 ( bool ) strstr ( strEsp8266_Fram_Record .Data_RX_BUF, reply2 ) ); 
 	
	else if ( reply1 != 0 )
		return ( ( bool ) strstr ( strEsp8266_Fram_Record .Data_RX_BUF, reply1 ) );
	
	else
		return ( ( bool ) strstr ( strEsp8266_Fram_Record .Data_RX_BUF, reply2 ) );
}
