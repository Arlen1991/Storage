#ifndef __WIFI_H
#define __WIFI_H

#include "mytypedef.h"
#include "wifi.h"
#include "usart.h"
#include "string.h"

#define     WiFi_Usart                          USART3
#define     ESP8266_Usart( fmt, ... )           USART_printf ( WiFi_Usart, fmt, ##__VA_ARGS__ ) 
#define     PC_Usart( fmt, ... )                printf ( fmt, ##__VA_ARGS__ )
bool ESP8266_Net_Mode_Choose ( ENUM_Net_ModeTypeDef enumMode );
bool ESP8266_Cmd ( char * cmd, char * reply1, char * reply2, u32 waittime );

void ESP8266_init( void );
void ConnectToServer(void);

#endif 
