/******************************************************************************
�������ڵ�����
���ܣ�
ʱ�䣺2018��1��29��09:54:13
���ߣ�Arlen
*******************************************************************************/

#include "I2C.h" 
#include "delay.h"
#include "int0.h"
#include "uart.h"
#include "AM2320.h"
#include "light.h"
#include "protocol.h"


extern bit Uart1RecvComplete;

bit flag_sleep=0; 
bit flag_exitsleep=0;
extern xdata u8 UartRecvBuf[MAXUARTRECVNUM];
Node sensor;
sbit  LED1 = P1^1;u8 sensordatabuff[MAXUARTRECVNUM];
void SystemInit(void)
{   //����P2^6
    P2M1&=~0x40;
    P2M0|=0x40;
    P26=0;

    delaynms(2);
    am2320Iint() ;
    Inter0Init();
    Usart_Init();
    flag_sleep=0; //ϵͳ���߱�־λ

}

void sleepcontrol()
{
    if(flag_sleep==1)
    {
        flag_sleep=0;
        
    }
    while(1)
    {
        if(PowerDownMode()==0x00)
         {
            flag_exitsleep=1;
            LED1 = 0;                 //����  
            break;	 
         }
               			  
    }
    SystemInit();

}

//ģ�⴫��������

void samplesensotdat(Node *snode)
{
    snode->addr = 28;
    sampletem_hum(snode);
    samplelight(snode);
    snode-> sensordata[3]=0;    snode-> sensordata[4]=0;
}

void main()
{
    u8 uartrecv;
    SystemInit();
   // WriteNByte(0xB8);
    while(1)
    {   
    sleepcontrol();
    if(flag_exitsleep==1)
    {
       flag_exitsleep=0;
       
       
       samplesensotdat(&sensor);
       delaynms(4000);
       createframedata(sensordatabuff,&sensor);
       UartSendStr(sensordatabuff,MAXUARTRECVNUM);
         
    }
    if(Uart1RecvComplete==1)
    {
        uartrecv= UartRecvpro(UartRecvBuf);
        if(uartrecv==0)   
        {
         flag_sleep=1;
        }

        
    }     
    }
}