#include "delay.h"
void delay1us(void) 
{
  _nop_(); _nop_(); _nop_(); 
  _nop_(); _nop_(); _nop_(); 
}
void delay10us(void)
{
	u8 i;
	for(i=0;i<10;i++)
	delay1us();
}
void delay5us(void)
{
	u8 i;
	for(i=0;i<5;i++)
	delay1us();
}
void delay1ms(void)
{
  u8 i;
  u8 j;
  i=25;	
  do{
    	j=44;
		while(j--);
    }while(i--); 
}
void delaynms(u16 xms)
{
	u16 i;
	for(i=0;i<xms;i++)
	{
		 delay1ms();
	}
}  