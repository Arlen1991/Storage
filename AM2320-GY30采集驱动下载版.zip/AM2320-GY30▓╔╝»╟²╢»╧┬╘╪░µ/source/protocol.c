#include "typedef.h"
#include "protocol.h"
#include "uart.h"


#define STARTCHAR  0x55
#define DATACMD   'D'
#define FRAMELEN  25

#define localaddr 22
#define ACKCMD   'A'
#define MODIADDRCMD   'G'

u8 code SPECIALADDRCODE[]="MODIFYADDR";	


bit Uart1RecvComplete;

//У��ͺ���
static u16 checksum(u8 *s,u8 slen)
{
	 u16 i=0;
	 u8 j;
	 for(j=0;j<slen;j++)
	 {
		 i+=*s;
		 s++;
	 }
	 return i;
	 
}

u8 createframedata(u8 *d,Node *snode )
{
		u8 *m,i,k,j;
		u16 crc;
		d[0]=STARTCHAR;
		d[1]=snode->addr;
		d[2]=DATACMD;
		k=3;
		for(j=0;j<5;j++)
		{
				m=(u8 *)&(snode->sensordata[j]);
				for(i=0;i<4;i++)
				{
					d[k++]=*m;
					m++;
				}
		}
		crc=checksum(&d[1],FRAMELEN-3);
		d[FRAMELEN-2]=crc/256;
		d[FRAMELEN-1]=crc%256;
		return 1;
}


u8 frameisvalid(u8 *s)
{
    u16 i,j;
	if(s[0]!=STARTCHAR)
			return 1;
    if(s[1]!=(localaddr&0xff))
    {
        
        return 2;
    }
    i=checksum(&s[1],FRAMELEN-3);
    j=s[FRAMELEN-2]*256+s[FRAMELEN-1];
    if(i!=j)		
    {
        
        return 3;
    }
    return 0;

}


//Ŀǰֻ����ACK����
//����ֵ 1:�յ�ACK���� 2:�޸ĵ�ַ
u8 cmdprocess(u8 *s)
{
	u8 i,scmd,j;
	u16 m,n;
	scmd=s[2];
	i=0;
	switch(scmd)
	{
		case ACKCMD:
			i=1;
		break;
		case MODIADDRCMD:
			m=s[3]*256+s[4];
			if(m!=localaddr)
				return 0;
			m=s[5]*256+s[6];
			n=s[7]*256+s[8];
			if(m!=n)
				return 0;
			for(j=0;j<10;j++)
			{
				if(s[9+j]!=SPECIALADDRCODE[j])
					return 0;
			}
			i=2;
			break;
  }
	
	return i;
	
}
u8 UartRecvpro(u8 *s)
{
    u8 i; 
	if(Uart1RecvComplete==0)
		 return 100;
	 Uart1RecvComplete=0;
	 
	 if(frameisvalid(s)!=0)
		 return 99;
	 i=cmdprocess(s);
	 if(i==1)
	 {
		 return 0;
		 
	 }
	 if(i==2)
	 {
		 return 1;
	 }
	 return 2;

}