#ifndef _PROTOCOL_H
#define _PROTOCOL_H

u8 createframedata(u8 *d,Node *snode );

u8 UartRecvpro(u8 *s);
#endif
