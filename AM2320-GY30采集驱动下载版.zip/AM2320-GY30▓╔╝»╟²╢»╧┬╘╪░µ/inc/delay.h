
#ifndef __DELAY_H
#define __DELAY_H
#include "typedef.h"

void delay1us(void);
void delay5us(void);
void delay10us(void);
void delay1ms(void);
void delaynms(u16 xms);

#endif