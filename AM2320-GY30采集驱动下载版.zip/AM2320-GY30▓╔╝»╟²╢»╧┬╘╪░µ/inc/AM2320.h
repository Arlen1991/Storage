#ifndef _AM2320_H
#define _AM2320_H

#include "typedef.h"

#define IIC_Add 0xB8    //������ַ
void am2320Iint();
void Waken(void);
void WriteNByte(u8 sla);
void ReadNByte(u8 Sal, u8 *p);
void sampletem_hum(Node *nd);

#endif