#ifndef _INT0_H
#define _INT0_H

#include "typedef.h"


void Inter0Init(void);

u8 PowerDownMode(void);

void powercontrol(u8 s);

#endif