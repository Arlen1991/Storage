#ifndef __UART_H
#define __UART_H
#include <STC15F2K60S2.H>
#include "intrins.h"
#include "typedef.h"

#define MAXUARTRECVNUM 25
void Usart_Init();
extern u8 UartSendStr(u8 *s,u8 slen);
#endif