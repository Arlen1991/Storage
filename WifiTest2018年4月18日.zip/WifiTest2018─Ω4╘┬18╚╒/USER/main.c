#include "stdio.h"
#include "stm32f10x.h"
#include "lcd.h"
#include "usart.h"	
#include "delay.h"
#include "wifi.h"
#include "rtc.h"


 int main(void)
 {	

 
    PCuart_init(115200);
    Wifiuart_init(9600);
    delay_init();
    LCD_Init();

   while(RTC_Init())		//RTC��ʼ��	��һ��Ҫ��ʼ���ɹ�
	{ 
		LCD_ShowString(60,130,200,16,16,"RTC ERROR!   ");	
		delay_ms(800);
		LCD_ShowString(60,130,200,16,16,"RTC Trying...");	
	}
//RTC_Set(2054,4,6,8,12,34);    
    //��ʾʱ��
	POINT_COLOR=BLUE;//��������Ϊ��ɫ					 
	LCD_ShowString(60,130,200,16,16,"    -  -     ");	   
	LCD_ShowString(60,172,200,16,16,"  :  :  ");
//    
//        ESP8266_init();
//    PC_Usart("Initation ok\r\n");
//     delay_ms(1000);
//     ConnectToServer();
  while(1)
  {
      	MakeRTCRun();	  
//      ESP8266_Usart("wifi send ok %d \r\n",i++);
//    delay_ms(1000);
  }
 }
