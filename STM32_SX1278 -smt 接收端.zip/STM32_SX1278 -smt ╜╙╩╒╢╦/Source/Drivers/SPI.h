#ifndef __SPI_H__
#define	__SPI_H__

 void SPI2_Init(void);
 INT8U SPI_ExchangeByte( u8 input );
#endif
