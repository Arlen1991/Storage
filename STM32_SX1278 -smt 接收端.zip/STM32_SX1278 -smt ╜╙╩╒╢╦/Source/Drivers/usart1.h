
#ifndef __USART1_H__
#define __USART1_H__

#include "stm32f10x.h"
#include <stdio.h>

#define uint16    unsigned short int 
void Uart1Init(void);

void UART_PutStr (USART_TypeDef* USARTx, char *str) ;
#endif

