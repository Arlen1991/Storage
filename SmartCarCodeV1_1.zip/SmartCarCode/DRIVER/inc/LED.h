#ifndef _LED_H
#define _LED_H
#include "sys.h"
#define ON  0
#define OFF 1


//#define LED PBout(5)// PB5
#define LED1(a) if(a) \
											GPIO_SetBits(GPIOB,GPIO_Pin_0); \
								else \
											GPIO_ResetBits(GPIOB,GPIO_Pin_0)


void GPIO_LEDInint(void);
void LED_Flash(void);                             
#endif
