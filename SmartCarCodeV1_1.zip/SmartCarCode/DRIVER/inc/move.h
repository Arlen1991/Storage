#ifndef _MOVE_H
#define _MOVE_H

#define uint16    unsigned short int 
    #define uint8  unsigned char
#define MOTOR_NUM 9
    
void GraySensorIOInint(void);
void CarSeachLine(void);
void CarGoStringht(void);  
#endif
