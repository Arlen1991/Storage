#ifndef TIMER_H
#define TIMER_H

#include "stm32f10x.h"
 
void Timer_Init(void);
void Timer_ON(void);
void Timer_OFF(void);

#endif	/* TIME_TEST_H */
