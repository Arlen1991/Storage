/**********************************************************************************/
#include "timer.h"
/**********************��ʱ��2�ж����ú���*****************************************/
void TIM2_NVIC_Configuration(void)
{
    NVIC_InitTypeDef NVIC_InitStructure; 
    
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);  													
    NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;	  
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;	
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}
/**************************************************************************************/
/**********************��ʱ��3�ж����ú���*********************************************/
void TIM3_NVIC_Configuration(void)
{
    NVIC_InitTypeDef NVIC_InitStructure; 
    
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);  													
    NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;	  
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;	
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}
/**************************************************************************************/
/**********************��ʱ��4�ж����ú���*********************************************/
void TIM4_NVIC_Configuration(void)
{
    NVIC_InitTypeDef NVIC_InitStructure; 
    
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);  													
    NVIC_InitStructure.NVIC_IRQChannel = TIM4_IRQn;	  
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;	
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

void TIM5_NVIC_Configuration(void)
{
    NVIC_InitTypeDef NVIC_InitStructure; 
    
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);  													
    NVIC_InitStructure.NVIC_IRQChannel = TIM5_IRQn;	  
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;	
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}
/**************************************************************************************/

/************************��ʱ��2���ú���***********************************************/
void TIM2_Configuration(u16 arr,u16 psc)
{
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);
    
	  TIM_DeInit(TIM2);											/* ����������ʱ�� */

    TIM_TimeBaseStructure.TIM_Period=arr;		 				/* �Զ���װ�ؼĴ������ڵ�ֵ(����ֵ) */
    TIM_TimeBaseStructure.TIM_Prescaler=psc;						/* ʱ��Ԥ��Ƶ�� 72M/72 */
    //TIM_TimeBaseStructure.TIM_ClockDivision=TIM_CKD_DIV1; 		/* �ⲿʱ�Ӳ�����Ƶ */
		TIM_TimeBaseStructure.TIM_RepetitionCounter = 0; 
	  TIM_TimeBaseStructure.TIM_ClockDivision=0;  
    TIM_TimeBaseStructure.TIM_CounterMode=TIM_CounterMode_Up; 	/* ���ϼ���ģʽ */
    TIM_TimeBaseInit(TIM2,&TIM_TimeBaseStructure);

    TIM_ClearFlag(TIM2,TIM_FLAG_Update);						/* �������жϱ�־ */

    TIM_ITConfig(TIM2,TIM_IT_Update,ENABLE);					/* �����жϴ���*/   
	
	  TIM_Cmd(TIM2,DISABLE);	


}

/**************************************************************************************/
/************************��ʱ��4���ú���***********************************************/
void TIM4_Configuration(u16 arr,u16 psc)
{
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4,ENABLE);
    
	  TIM_DeInit(TIM4);											/* ����������ʱ�� */

    TIM_TimeBaseStructure.TIM_Period=arr;		 				/* �Զ���װ�ؼĴ������ڵ�ֵ(����ֵ) */
    TIM_TimeBaseStructure.TIM_Prescaler=psc;						/* ʱ��Ԥ��Ƶ�� 72M/72 */
    TIM_TimeBaseStructure.TIM_ClockDivision=0; 		/* �ⲿʱ�Ӳ�����Ƶ */
		TIM_TimeBaseStructure.TIM_RepetitionCounter = 0; 
    TIM_TimeBaseStructure.TIM_CounterMode=TIM_CounterMode_Up; 	/* ���ϼ���ģʽ */
    TIM_TimeBaseInit(TIM4,&TIM_TimeBaseStructure);

    TIM_ClearFlag(TIM4,TIM_FLAG_Update);						/* �������жϱ�־ */

    TIM_ITConfig(TIM4,TIM_IT_Update,ENABLE);					/* �����жϴ���*/   
	
	  TIM_Cmd(TIM4,DISABLE);	
}
/**************************************************************************************/
/************************��ʱ�����ú���************************************************/
void TIM5_Configuration(u16 arr,u16 psc)
{
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM5 , ENABLE);
    
	  TIM_DeInit(TIM5);											/* ����������ʱ�� */

    TIM_TimeBaseStructure.TIM_Period=arr;		 				/* �Զ���װ�ؼĴ������ڵ�ֵ(����ֵ) */
    TIM_TimeBaseStructure.TIM_Prescaler=psc;						/* ʱ��Ԥ��Ƶ�� 72M/72 */
    TIM_TimeBaseStructure.TIM_ClockDivision=TIM_CKD_DIV1; 		/* �ⲿʱ�Ӳ�����Ƶ */
    TIM_TimeBaseStructure.TIM_CounterMode=TIM_CounterMode_Up; 	/* ���ϼ���ģʽ */
    TIM_TimeBaseInit(TIM5, &TIM_TimeBaseStructure);

    TIM_ClearFlag(TIM5, TIM_FLAG_Update);						/* �������жϱ�־ */

    TIM_ITConfig(TIM5,TIM_IT_Update,ENABLE);					/* �����жϴ���*/    
	
	  TIM_Cmd(TIM5,DISABLE);									    /* �رն�ʱ�� */ 
}
/**************************************************************************************/
/************************��ʱ����ʼ������*********************************************/
void Timer_Init(void)
{
	TIM2_NVIC_Configuration();
	TIM2_Configuration(2055,71);

    TIM3_NVIC_Configuration();


	//TIM4_NVIC_Configuration();
	//TIM4_Configuration(2000,71);

	TIM5_NVIC_Configuration();
    TIM5_Configuration(2025,71);
    //TIM5_Configuration(4999,71);
}
/**************************************************************************************/
/************************������ʱ������************************************************/
void Timer_ON(void)
{	
	TIM_Cmd(TIM2,ENABLE);
	//TIM_Cmd(TIM3,ENABLE);
	//TIM_Cmd(TIM4,ENABLE);	
	TIM_Cmd(TIM5,ENABLE);	
}
/**************************************************************************************/
/************************�رն�ʱ������************************************************/
void Timer_OFF(void)
{	
	TIM_Cmd(TIM2,DISABLE);
	TIM_Cmd(TIM3,DISABLE);
//	TIM_Cmd(TIM4,DISABLE);	
	TIM_Cmd(TIM5,DISABLE);
}
/**************************************************************************************/

