//Ѱ��������ü�����
#include "move.h"
#include "motor.h"
#include "servor.h"
#define Motor_Pwm 800
#define GrayNum 9
uint16 CPWM[MOTOR_NUM]=   {1500,1320,1500,1500,1500,1500,1500,1500,1500};
uint16 AngleGate[GrayNum]={970,1070,1170,1270,1350,1500,1680,1800,1920};
u16 graystate;
//�Ҷȴ������ӿڶ���
#define  right4 GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_1)
#define  right3 GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_1)
#define  right2 GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_7)    //C7��
#define  right1 GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_6)
#define  mid    GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_5)
#define  left1  GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_4)
#define  left2  GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_3)
#define  left3  GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_14)
#define  left4  GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_2)

void GraySensorIOInint(void)
{
    GPIO_InitTypeDef GPIOC_InitStructure;  //����GPIOC�ܽŽṹ�����
    GPIO_InitTypeDef GPIOB_InitStructure;
    GPIO_InitTypeDef GPIOA_InitStructure;
	
	RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOC|RCC_APB2Periph_GPIOA|RCC_APB2Periph_GPIOB,ENABLE);//����GPIOC����ʱ��
	
	GPIOC_InitStructure.GPIO_Pin = GPIO_Pin_7|GPIO_Pin_6|GPIO_Pin_5|GPIO_Pin_4|GPIO_Pin_3|GPIO_Pin_2|GPIO_Pin_1;
	GPIOC_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;   //������ø�������	
	GPIO_Init(GPIOC,&GPIOC_InitStructure);
    
    	GPIOB_InitStructure.GPIO_Pin = GPIO_Pin_1;
	GPIOC_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;   //������ø�������	
	GPIO_Init(GPIOB,&GPIOB_InitStructure);
    
    	GPIOA_InitStructure.GPIO_Pin = GPIO_Pin_14;
	GPIOC_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;   //������ø�������	
	GPIO_Init(GPIOA,&GPIOA_InitStructure);

}

void CarTurnAround(uint16 angle,int speed)
{
    CPWM[1]=angle;
    Set_Pwm(speed,speed+18);
}

u16 readgraystate(void)
{
    u16 i;
    i=((left4<<8) + (left3<<7) + (left2<<6) + (left1<<5) + (mid<<4) + (right1<<3)+ (right2<<2)+ (right3<<1)+ right4);
    return i;
}

//����Ƕ���ת-��ת 970,1070,1170,1270,1350,1500,1680,1800,1920
void CarSeachLine(void)
{
    graystate=readgraystate();
   switch(graystate)
   {
        case 16:CarTurnAround(AngleGate[4],Motor_Pwm);break;                    //0000 1 0000   1350
		case 56:CarTurnAround(AngleGate[4],Motor_Pwm);break;                    //0001 1 1000
       
		case 24:CarTurnAround(AngleGate[5],Motor_Pwm);break;          //0000 1 1000    1500
	    case 8 :CarTurnAround(AngleGate[5],Motor_Pwm);break;          //0000 0 1000
       
		case 12:CarTurnAround(AngleGate[6],Motor_Pwm);break;   //0000 0 1100     1680
	    case 4 :CarTurnAround(AngleGate[6],Motor_Pwm);break;   //0000 0 0100
       
		case 6 :CarTurnAround(AngleGate[7],Motor_Pwm);break;      //0000 0 0110      1800
	    case 2 :CarTurnAround(AngleGate[7],Motor_Pwm);break;      //0000 0 0010
       
		case 3 :CarTurnAround(AngleGate[8],Motor_Pwm);break;                 //0000 0 0011      1920
		case 1 :CarTurnAround(AngleGate[8],Motor_Pwm);break;                 //0000 0 0001
		 
		case 48:CarTurnAround(AngleGate[3],Motor_Pwm);break;           //0001 1 0000     1270
		case 32:CarTurnAround(AngleGate[3],Motor_Pwm);break;           //0001 0 0000
       
		case 96:CarTurnAround(AngleGate[2],Motor_Pwm);break;    //0011 0 0000    1170
		case 64:CarTurnAround(AngleGate[2],Motor_Pwm);break;    //0010 0 0000
       
		case 192:CarTurnAround(AngleGate[1],Motor_Pwm);break;      //0110 0 0000    1070
		case 128:CarTurnAround(AngleGate[1],Motor_Pwm);break;      //0100 0 0000
        
		case 384:CarTurnAround(AngleGate[0],Motor_Pwm);break;                 //1100 0 0000   970
        case 256:CarTurnAround(AngleGate[0],Motor_Pwm);break;                 //1000 0 0000  
        default: break;		 
		 
   }       
	
}

void CarGoStringht(void)
{
    CPWM[1]=1500;
    Set_Pwm(Motor_Pwm,Motor_Pwm+18);
}
